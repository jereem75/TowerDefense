#include <stdio.h>
#include <stdlib.h>
#include "../include/graphique.h"
#include "../include/generation_terrain.h"
#include "../include/gestion_gemme.h"
#include "../include/gestion_tour.h"
#include <MLV/MLV_all.h>
#include <math.h>


void afficher_plateau(Terrain *jeu) {
    int i, j;
    for (i = 0; i < LIG; i++) {
        for (j = 0; j < COL; j++) {
            MLV_draw_filled_rectangle(j* LONGUEUR_CASE, i * LONGUEUR_CASE, LONGUEUR_CASE , LONGUEUR_CASE, MLV_COLOR_GREEN4);
            MLV_draw_rectangle(j * LONGUEUR_CASE, i * LONGUEUR_CASE, LONGUEUR_CASE, LONGUEUR_CASE, MLV_COLOR_BLACK);
        }
    }
    for(int i = 0; i < jeu->longueur; i++){
        MLV_draw_filled_rectangle(jeu->chemin[i].y * LONGUEUR_CASE, jeu->chemin[i].x * LONGUEUR_CASE, LONGUEUR_CASE , LONGUEUR_CASE, MLV_COLOR_YELLOW1);
        MLV_draw_rectangle(jeu->chemin[i].y * LONGUEUR_CASE, jeu->chemin[i].x * LONGUEUR_CASE, LONGUEUR_CASE , LONGUEUR_CASE, MLV_COLOR_BLACK);
    }
    MLV_draw_filled_rectangle(jeu->chemin[0].y * LONGUEUR_CASE, jeu->chemin[0].x * LONGUEUR_CASE, LONGUEUR_CASE , LONGUEUR_CASE, MLV_COLOR_PURPLE1);
    MLV_draw_filled_rectangle(jeu->chemin[jeu->longueur - 1].y * LONGUEUR_CASE, jeu->chemin[jeu->longueur - 1].x * LONGUEUR_CASE, LONGUEUR_CASE , LONGUEUR_CASE, MLV_COLOR_RED);
    
}


void affiche_file_gemme(Game jeu){
    int length = jeu.gemmes.nb_gemmes_file;
    for(int i = 0; i < 10; i++){
        MLV_draw_filled_rectangle(i * 50, 1320, 80, 80, MLV_COLOR_WHITE);
        MLV_draw_rectangle(i * 50, 1320, 80, 80, MLV_COLOR_BLACK); 
        if (i < length) {
            MLV_draw_filled_circle(i * 50 + 25, 1360, 20, convert_angle_to_color(jeu.gemmes.lst_gemmes_file[i].teinte));
        }
    }
}





void affiche_infos(){
    MLV_draw_adapted_text_box(0,1255,"Gemmes générées:", 25, MLV_COLOR_BLACK, MLV_COLOR_WHITE, MLV_COLOR_BLACK, MLV_TEXT_CENTER);
    MLV_draw_text_box(1350,1190,150,100,"Generer une gemme",25,MLV_COLOR_BLACK,MLV_COLOR_BLACK,MLV_COLOR_WHITE,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
}

void affiche_mana(Mana mana){
    MLV_draw_adapted_text_box(0,1190,"MANA: %d", 25, MLV_COLOR_BLACK, MLV_COLOR_RED, MLV_COLOR_BLACK, MLV_TEXT_CENTER, mana.nb_mana);
    MLV_draw_text_box(1250, 1300, 250, 100, "Augmenter vers niveau %d: %d mana",25, MLV_COLOR_BLACK,MLV_COLOR_BLACK,MLV_COLOR_WHITE,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER, mana.niveau + 1, (int)(500 * pow(1.4, mana.niveau)) );
}


int clic(Game *game, int *statut_t, int *statut_gemme) {
    MLV_Event event;
    MLV_Keyboard_button key_sym;
    MLV_Mouse_button mouse_button;
    int unicode;
    char *texte;
    MLV_Input_box *input_box;
    int x, y;
    MLV_Button_state state;
    event = MLV_wait_event(&key_sym, NULL, &unicode, &texte, &input_box, &x, &y, &mouse_button, &state);
    if (event == MLV_MOUSE_BUTTON) {
        if (state == MLV_RELEASED) {
            if (x > 1350 && x < 1500 && y > 1190 && y < 1290) {
                cree_gemme(&(game)->mana, &(game)->gemmes, 0);
                return 0;
            }
            else if(x > 1250 && x < 1500 && y > 1300 && y < 1400){
                up_lvl_mana( &(game)->mana);
            }
            else if( x < 500  && y > 1320 && y < 1400){
                if(*statut_gemme == -1){
                    *statut_gemme = x / 50;
                    printf("%d\n", x/50);
                }
                else{
                    if(est_case_grille(x,y) == 0 ){
                        add_gemme_tour(&(game->gemmes), &(game)->tours, &(game)->gemmes.lst_gemmes_file[*statut_gemme], y / LONGUEUR_CASE, x / LONGUEUR_CASE );
                        *statut_gemme = -1;
                    }
                    else{
                        fusionne(&(game)->mana, &(game)->gemmes,&(game)->gemmes.lst_gemmes_file[*statut_gemme],&(game)->gemmes.lst_gemmes_file[x/ 50 ]);
                        //affiche_file_gemme(*game);
                        *statut_gemme = -1;
                    }
                    
                }
            }
            else if (*statut_t == 1) {
                if (est_case_grille(x, y) != 1){
                    build_tour(game->plateau, &(game)->mana, &(game)->tours, y/LONGUEUR_CASE, x/LONGUEUR_CASE);
                }
            }
        }
    } else if (event == MLV_KEY) {
        if (key_sym == MLV_KEYBOARD_q) {
            return -1;
        } else if (key_sym == MLV_KEYBOARD_t) {
            *statut_t *= -1;
        }
    }

    return 0;
}

// a modifier
MLV_Color convert_angle_to_color(int angle) {
    // Convertissez l'angle HSL en RGB
    float h = angle / 360.0;
    float s = 1.0;  // Saturation à 100%
    float l = 0.5;  // Luminance à 50%

    // Convertissez de l'espace HSL à RGB
    float C = (1 - fabs(2 * l - 1)) * s;
    float X = C * (1 - fabs(fmod(h * 6, 2) - 1));
    float m = l - C / 2;

    float r, g, b;

    if (h < 1.0 / 6.0) {
        r = C;
        g = X;
        b = 0;
    } else if (h < 2.0 / 6.0) {
        r = X;
        g = C;
        b = 0;
    } else if (h < 3.0 / 6.0) {
        r = 0;
        g = C;
        b = X;
    } else if (h < 4.0 / 6.0) {
        r = 0;
        g = X;
        b = C;
    } else if (h < 5.0 / 6.0) {
        r = X;
        g = 0;
        b = C;
    } else {
        r = C;
        g = 0;
        b = X;
    }

    // Convertissez les composants de couleur de la plage [0, 1] à [0, 255]
    Uint8 red = (Uint8)((r + m) * 255);
    Uint8 green = (Uint8)((g + m) * 255);
    Uint8 blue = (Uint8)((b + m) * 255);

    // Utilisez votre fonction MLV_convert_rgba_to_color pour obtenir le MLV_Color
    return MLV_convert_rgba_to_color(red, green, blue, 255);
}


int est_case_grille(int x, int y){
    fprintf(stderr, "%d,%d\n", x, y);
    if (x > 28 * LONGUEUR_CASE || y > 22 * LONGUEUR_CASE){
        printf("non\n");
        return 1;
    }
    return 0;
}


void affiche_tours(Game jeu){
    int n = jeu.tours.nb_tours;
    for(int i = 0; i < n; i++){
        if(jeu.tours.lst_tours[i].gem.teinte != -1){
            MLV_draw_filled_circle(jeu.tours.lst_tours[i].position.y * LONGUEUR_CASE + LONGUEUR_CASE / 2, jeu.tours.lst_tours[i].position.x * LONGUEUR_CASE + LONGUEUR_CASE / 2, LONGUEUR_CASE / 2, convert_angle_to_color(jeu.tours.lst_tours[i].gem.teinte ));
        }
        else{
            MLV_draw_filled_circle(jeu.tours.lst_tours[i].position.y * LONGUEUR_CASE + LONGUEUR_CASE / 2, jeu.tours.lst_tours[i].position.x * LONGUEUR_CASE + LONGUEUR_CASE / 2, LONGUEUR_CASE / 2, MLV_COLOR_GREY);
        }
    }
}