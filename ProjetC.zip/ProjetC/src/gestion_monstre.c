#include <stdio.h>
#include <stdlib.h>
#include "../include/gestion_monstre.h"