#include <stdio.h>
#include <stdlib.h>
#include "../include/generation_terrain.h"
#include <time.h>


int main(){
    srand(time(NULL));
    Terrain test;
    test.chemin = NULL;
    initialise_cases(&test);
    //afficherTableau(test);
    generation(&test);
    affiche_chemin(test);
    printf("longuueur = %d, virage = %d\n", test.longueur, test.nb_virages);
    return 0;
}