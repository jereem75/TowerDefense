#include <stdio.h>
#include <stdlib.h>
#include "../include/generation_terrain.h"
#include "../include/gestion_mana.h"
#include <time.h>
#include <MLV/MLV_all.h>
#include "../include/graphique.h"
#include "../include/moteur.h"

int main(){
    MLV_create_window("TowerDefense", "TowerD", 1512, 1500); // on cree la fenetre graphique
    srand(time(NULL));
    Game jeu;
    initialise(&jeu);
    //afficherTableau(test);
    generation(&(jeu).plateau); // on genere le chemin
    printf("main\n");
    //affiche_chemin(jeu.plateau);
    afficher_plateau(&(jeu).plateau); // on affiche le plateau
    moteur(&jeu); // on lance le jeu
    //MLV_wait_seconds(5);
    MLV_clear_window(MLV_COLOR_BLACK);
    affiche_resultats(jeu);
    MLV_free_window();
    return 0;
}