#include <stdio.h>
#include <stdlib.h>
#include "../include/gestion_tirs.h"
#include "../include/gestion_monstre.h"
#include "../include/generation_terrain.h"
#include "../include/gestion_gemme.h"
#include <math.h>



void initialisation_tir(Tir *tir, int x_tour, int y_tour){
    tir->indice_monstre = -1;
    tir->indice_vague = -1;
    tir->nb_tirs = 0;
    tir->x =(double) x_tour;
    tir->y =(double) y_tour;
}

void update_tir(Mana *mana, Tir *tir, Lst_Vague *vague, Gemme gemme, int tour_x, int tour_y) {
    if (tir->nb_tirs == 2) {
        //printf("test1\n");
        return;
    }
    if(tir->indice_monstre != -1 && tir->indice_vague != -1){
        if(calcul_distance_monstre_tir((*tir), vague->tab[tir->indice_vague].monstres[tir->indice_monstre].x, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].y) <= 3.0/60.0){
            //printf("test1\n");
            tir->nb_tirs ++;
            vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants -= degats(gemme, tir, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].teinte) ;
            if( vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants < 0){
                vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants = 0;
                gain_mana(mana, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_initial);
            }
            tir->x = tour_x;
            tir->y = tour_y;
            tir->indice_monstre = -1;
            tir->indice_vague = -1;
        }
        else{
            tir->x = tir->x + calcul_vecteur_unitaire(*tir, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].x, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].x, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].y, tir->x) * 3.0/60.0;
            tir->y = tir->y + calcul_vecteur_unitaire(*tir, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].y, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].x, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].y, tir->y) * 3.0/60.0;

        }
    return;
    }
    int hp_max = 0;
    for (int i = 0; i < vague->vague_actuelle; i++) {
        for (int j = 0; j < vague->tab[i].nb_monstres; j++) {
            if (vague->tab[i].monstres[j].hp_restants > hp_max && vague->tab[i].monstres[j].hp_restants > 0) {
                if (est_dans_rayon(*tir, vague->tab[i].monstres[j].x, vague->tab[i].monstres[j].y) == 1) {
                    tir->indice_monstre = j;
                    tir->indice_vague = i;
                    hp_max = vague->tab[i].monstres[j].hp_restants;
                }
            }
        }
    }
    /*if(tir->indice_monstre >= 0 && tir->indice_vague >= 0){
        vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants -= degats(gemme, tir, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].teinte) ;
        if( vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants < 0){
            vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_restants = 0;
            gain_mana(mana, vague->tab[tir->indice_vague].monstres[tir->indice_monstre].hp_initial);
        }
        tir->nb_tirs ++; // faire le tir
        tir->indice_monstre = -1;
        tir->indice_vague = -1;
    }*/
    
}



int est_dans_rayon(Tir tir, int x_monstre, int y_monstre) {
    double distance = sqrt(pow(tir.x - x_monstre, 2) + pow(tir.y - y_monstre, 2));
    if (distance <= 3) {
        //printf("test\n");
        return 1;
    }
    return 0;
}


int degats(Gemme gemme, Tir *tir, int teinte_monstre) {
    int nb = (int)(D * pow(2.0, gemme.niveau) * (1.0 - cos(gemme.teinte - teinte_monstre) / 2.0));
    printf("degat %d\n", nb);
    return nb;
}

double calcul_distance_monstre_tir(Tir tir, double x_monstre, double y_monstre) {
    return sqrt(pow(x_monstre - tir.x, 2) + pow(y_monstre - tir.y, 2));
}


double calcul_vecteur_unitaire(Tir tir, double monstre_coord, double monstre_x, double monstre_y, double tir_coord){
    return (monstre_coord - tir_coord) / calcul_distance_monstre_tir(tir, monstre_x, monstre_y);
}