#ifndef GESTION_TO
#define GESTION_TO
#include "../include/gestion_gemme.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct{
    int x;
    int y;
    Gemme gemme;
}Tour;

typedef struct{
    Tour *lst_tours;
}Lst_Tour;


#endif
