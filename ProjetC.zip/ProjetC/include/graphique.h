#ifndef GRAPH
#define GRAPH

#include <stdlib.h>
#include <stdio.h>

typedef enum{
    HAUT,
    BAS,
    GAUCHE,
    DROITE
}Direction;


#endif
