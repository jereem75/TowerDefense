#ifndef GESTION_M
#define GESTION_M

#include <stdlib.h>
#include <stdio.h>
#define NB_MAX 24

typedef enum{
    NORMAL,
    FOULE,
    AGILE,
    BOSS
}Type;

typedef struct{
    int vitesse;
    int hp_restants;
    int hp_initial;
    int teinte;
} Monstre;

typedef struct{
    Type type_vague;
    int nb_vague;
    Monstre *monstres;
    int nb_monstres;
    int vitesse;
} Vague;

/* fonction qui renvoie un type de vague en fonction des probabilites*/
Type random_vague();

/* fonction qui initialise la structure Monstre*/
void intialisation_monstre(Vague *new);

/* fonction qui initialise la structure Vague */
void initialisation_vague(Vague *new);

#endif
