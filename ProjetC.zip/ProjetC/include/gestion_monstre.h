#ifndef GESTION_M
#define GESTION_M

#include <stdlib.h>
#include <stdio.h>
#define NB_MAX 100

typedef struct{
    int type;
    int vitesse;
    int hp_restants;
    int hp_initial;
    int teinte;
} Monstre;

typedef struct{
    int type_vague;
    Monstre monstres[NB_MAX];
    int nb_monstres;
} Vague;

#endif
