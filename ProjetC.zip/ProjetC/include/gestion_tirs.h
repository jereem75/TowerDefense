#ifndef GESTION_TI
#define GESTION_TI

#include <stdlib.h>
#include <stdio.h>
#include "generation_terrain.h"
#include "gestion_monstre.h"
#include "gestion_gemme.h"
#define D 10

typedef struct{
    double x;
    double y;
    int indice_vague;
    int indice_monstre;
    int nb_tirs; 
}Tir;

void initialisation_tir(Tir *tir, int x_tour, int y_tour);

void update_tir(Mana *mana, Tir *tir, Lst_Vague *vague, Gemme gemme, int tour_x, int tour_y, int longueur_chemin); 

int est_dans_rayon(Tir tir, int x_monstre, int y_monstre);

int degats(Gemme gemme, Tir tir, int teinte_monstre);

double calcul_distance_monstre_tir(Tir tir, double x_monstre, double y_monstre);

double calcul_vecteur_unitaire(Tir tir, double monstre_coord, double monstre_x, double monstre_y, double tir_coord);

void frappe_monstre(Tir *tir, Gemme gemme, Lst_Vague *vague, Monstre *monstre, Mana *mana);

void applique_pyro_monstres(Gemme gemme, Tir tir, Lst_Vague *vague, Monstre monstre);

void applique_pyro_hydro(Gemme gemme, Tir tir, Lst_Vague *vague, Monstre monstre);

#endif
