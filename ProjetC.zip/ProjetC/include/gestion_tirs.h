#ifndef GESTION_TI
#define GESTION_TI

#include <stdlib.h>
#include <stdio.h>



#endif
