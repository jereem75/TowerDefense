#ifndef GESTION_G
#define GESTION_G

#include <stdlib.h>
#include <stdio.h>
#include "../include/gestion_gemme.h"

#define MAX_GEMMES 100
typedef struct{
    int niveau;
    int type;
    int teinte;
} Gemme;


typedef struct{
    Gemme lst_gemmes[MAX_GEMMES];
    int nb_gemmes;
} Liste_gemme;



#endif
